from setuptools import setup

setup(
	name="paquete",
	version="0.1",
	description="Este es un paquete de ejemplo",
	author="Will Arevalo",
	author_email="thewillfap@gmail.com",
	url="http://willarevalo.github.io",
	script=[],
	packages=["paquete", "paquete.adios", "paquete.hola"]
)